# UNFuzzy

Fuzzy Logic Systems - FSL (Fuzzy controllers), and networks of FSLs

UNFuzzy es un software para diseño de Sistemas de Lógica Difusa (Controladores difusos). 
UNFuzzyNetwork permite el diseño de Redes de Sistemas de Lógica Difusa.

Para compilarlo se utiliza codeblocks y wxWidgets
