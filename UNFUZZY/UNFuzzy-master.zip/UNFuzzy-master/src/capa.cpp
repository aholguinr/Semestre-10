#include "capa.h"

capa::capa()
{
//	nodo* N1=new nodo(1,1);
//	Nodos.Add(N1);
}

capa::~capa()
{
	//dtor
}
