#include "pin.h"

#include <cstdio>

pin::pin()
{
	Contacto=NULL;
	Valor=0.0;
}

pin::~pin()
{
	//dtor
}
