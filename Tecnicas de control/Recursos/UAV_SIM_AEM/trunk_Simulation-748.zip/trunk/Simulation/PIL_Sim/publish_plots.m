%% Execute this code to publish the plots to a pdf file

publish('plot_pil.m',struct('format','pdf','showCode',false,'outputDir','pdf'));
close all;
